===============================
Patch Set Update (PSU) for Bug: 28710939
===============================

Date:  Fri Dec 21 13:46:56 2018
---------------------------------
Platform Patch for : Generic
Product Patched : ORACLE WEBLOGIC SERVER
Product Version      : 12.2.1.3.0


This document describes how to install the interim patch for
bug #  28710939. It includes the following sections:

	Section 1, "Zero Downtime Patching"

 	Section 2, "Prerequisites"

	Section 3, "Pre-Installation Instructions"

	Section 4, "Installation Instructions"

	Section 5, "Post-Installation Instructions"

	Section 6, "Deinstallation Instructions"

	Section 7, "Post Deinstallation Instructions"

	Section 8, "Bugs Fixed by This Patch"

        Section 9, "Known Issues"


 
1 Zero Downtime Patching
------------------------------
This patch has been marked as eligible for Zero Downtime Patching. 
The type of Zero Downtime Patching supported by this patch is FMW_ROLLING_ORACLE_HOME.

With Zero Downtime Patching, a Patch can be applied to a system in a manner
that does not incur any downtime. This ensures that the system can remain
available and functioning during the patching process. Certain
pre-requisites, however, must be met before the patch can be applied.

For more information, see the following:
Doc ID 1942159.1 Introduction to Zero Downtime (ZDT) Patching for Oracle Fusion Middleware / WebLogic Server 
https://support.oracle.com/rs?type=doc&id=1942159.1

 

2 Prerequisites
----------------
Ensure that you meet the following requirements before you install or
deinstall the patch:

1. Understand the PSU program:

Review the following before applying PSUs for the first time:

Doc ID 1306505.1 Patch Set Update (PSU) Administration Guide for Oracle 
WebLogic Server (WLS)
https://support.oracle.com/rs?type=doc&id=1306505.1


2. Update Java SE (JDK/JRE):

For users of Oracle JDKs and JVMs, we strongly recommend applying the latest
Java Critical Patch Updates (CPUs) as soon as they are released. Refer to the
following for further information:

Doc ID 1506916.1 Obtaining Java SE (JDK/JRE) for Oracle Fusion Middleware Products
https://support.oracle.com/rs?type=doc&id=1506916.1


3. Update OPatch:

Oracle Fusion Middleware 12.2.1 products are installed with OPatch NextGen 13.3
to apply interim patches. The OPatch utility should be updated over time to 
resolve known issues.

You can check your version using the following command:

   ORACLE_HOME/OPatch/opatch version

*** To install this PSU, you must use OPatch version 13.9.4.

If you try to install the PSU with an earlier opatch version (e.g. 13.9.2.0.0),
you will see an error similar to:

   "
   Verifying environment and performing prerequisite checks...
   Prerequisite check "CheckMinimumOPatchVersion" failed.
   The details are:

   The OPatch being used has version 13.9.2.0.0 while the following patch(es)
   require higher versions:
   Patch 28710939 requires OPatch version 13.9.4.0.0.
   Please download latest OPatch from My Oracle Support.
   "

*** OPatch 13.9.4 is available as Patch 28186730:
https://support.oracle.com/rs?type=patch&id=28186730

Review the following for more OPatch information:

Doc ID 1587524.1 Using OUI NextGen OPatch 13 for Oracle Fusion Middleware 12c (12.1.2+)
https://support.oracle.com/rs?type=doc&id=1587524.1

4. Update nginst: 
Please ensure you have NextGen OUI Framework 13.9.3.0.0.1 (or later) 
installed.  The 13.9.3.0.0.1 patch is available here:
https://support.oracle.com/rs?type=patch&id=29137924.   
NOTE:  If this patch is being installed on windows, please include the -oop 
option 

5. Verify the OUI Inventory.
OPatch needs access to a valid OUI inventory to apply patches.

Note: This needs the ORACLE_HOME to be set(refer section "2. Pre-Installation Instructions")
prior to run the below commands:

Validate the OUI inventory with the following commands:

$ opatch lsinventory -jre $ORACLE_HOME/oracle_common/jdk/jre

Note:
All OPatch commands should be run with -jre option.
Make sure the JDK version you use is the certified version for your product.

If the command errors out, contact Oracle Support and work to validate
and verify the inventory setup before proceeding.


6. Confirm the executables appear in your system PATH:

The patching process will use the unzip and the OPatch executables. After
setting the ORACLE_HOME environment, confirm if the following executables
exist, before proceeding to the next step:

- opatch
- unzip

If either of these executables do not show in the PATH, correct the
problem before proceeding.


7. Create a location for storing the unzipped patch: 

This location will be referred to later in the document as PATCH_TOP.

NOTE: On WINDOWS, the preferred location is the drive root directory.
For example, "C:\PATCH_TOP" and avoid choosing locations like,
"C:\Documents and Settings\username\PATCH_TOP".
This is necessary due to the 256 characters limitation on windows
platform.

3 Pre-Installation Instructions
-------------------------------

1. Set the ORACLE_HOME environment variable to the directory where you have installed ORACLE WEBLOGIC SERVER.

2. To install this PSU, you must use OPatch version 13.9.4. See Prerequisite section above.



4 Installation Instructions
---------------------------

1. Unzip the patch zip file into the PATCH_TOP.

$ unzip -d PATCH_TOP p28710939_122130_Generic.zip

NOTE: On WINDOWS, the unzip command has a limitation of 256 characters in the path name.
If you encounter this, please use an alternate ZIP utility like 7-Zip to unzip the patch.

For example: To unzip using 7-zip, run the command:
"c:\Program Files\7-Zip\7z.exe" x  p28710939_122130_Generic.zip

2. Set your current directory to the directory where the patch is located.

$ cd PATCH_TOP/28710939

3. Run OPatch to apply the patch.

$ opatch apply

Windows:
When applying interim patches with OPatch 13.9.4, Microsoft Windows platform needs the '-oop' option:

   <ORACLE_HOME>\OPatch\opatch apply <PATCH_HOME> -oop

where PATCH_HOME is a numbered directory where you extracted interim patch contents.

Note:
-----
When OPatch starts, it validates the patch and makes sure that there are no
conflicts with the software already installed in the ORACLE_HOME.

In case of opatch conflict, you will see a warning message similar to the one mentioned below:

Interim Patch XXXX has Conflict with patch(es) [ YYYY ] in OH ...
Conflict patches: YYYY
Patch(es) YYYY conflict with the patch currently being installed (XXXX).
If you continue, patch(es) YYYY will be rolled back and the new patch (XXXX) will be installed.

If a merge of the new patch (XXXX) and the conflicting patch(es) ( YYYY) is required,contact Oracle Support Services and request a Merged patch.

Do you want to proceed? [y|n]
n

You must stop the patch installation and the following should be reviewed:

Doc ID 1329952.1 Oracle Fusion Middleware Patch Conflict Resolution
https://support.oracle.com/rs?type=doc&id=1329952.1

Contact Oracle Support if the conflict cannot be resolved or you need a Merge Request.

5 Post-Installation Instructions
---------------------------------

Note:   The fix for bug 26929163 updates the runtime components for the 
WLS plugin for the RCU and Upgrade Assistant tools.  It will prevent any 
future WLS schema installs or upgrades from allowing WLS schema owners to 
retain ANY privs once installation or upgrade have been completed.  The 
patch will *not* affect schemas that have already been installed or 
upgraded to the correct schema version.

For existing installations that wish to remove the ANY privileges that 
have been assigned to the WLS schema owners, users can run the script 
located at $MW_HOME/oracle_common/common/sql/wlsservices/sql/cleanup.sql
as the DBA user and provide the WLS schema owner names.  For example, if 
the WLS schema owners are DEV1_WLS and DEV1_WLS_RUNTIME:

      sqlplus <dba-connect-info> cleanup.sql  DEV1_WLS  DEV1_WLS_RUNTIME


6 Deinstallation Instructions
------------------------------

If you experience any problems after installing this patch, remove the patch as
follows:

1. Make sure to follow the same Prerequisites or pre-install steps (if any)
when deinstalling a patch.
This includes setting up any environment variables like ORACLE_HOME and
verifying the OUI inventory before deinstalling.

2. Change to the directory where the patch was unzipped.

$ cd PATCH_TOP/28710939

3. Run OPatch to deinstall the patch.

$ opatch rollback -id  28710939

7 Post Deinstallation Instructions
-----------------------------------
Restart all servers (AdminServer and all Managed server(s)).

This is necessary to redeploy the original applications and bring the
environment back to it's original state.

8 Bugs Fixed by This Patch
--------------------------
23076695 Ensure use of factory methods when instantiating XMLInputFactory
23103220 CVE-2016-5535
25387569 STRESS-OSB- ConcurrentModificationException-transaction failed during testing
25488428 Fixed addition of WSS username token security header to JAXWS dispatch client with custom policy ID
25580220 Fixed an issue that prevented targeting MultiDatasource to a persistent store.
25665727 Fixed an issue where the admin server was consuming an inordinate amount of native memory
25750303 Fixed an issue where fluctuation in the network connection between the admin and managed server could cause a permanent disconnect between the two
25800186 Fixed an issue where a redirect from WLS did not add content-length or chunked-transfer in the response
25987400 Fixed an issue where it wasn't possible to provide indirect transaction propagation between servers that are on different networks
25993295 CVE-2013-1768
26026959 Fixed error 404 while loading deployed SOA composites after scale up of a dynamic cluster
26080417 Fixed an issue where an HTTP Response 204 was incorrectly including a response body of 0000
26098043 Provide app roles information in IDCS client for end-to-end authentication flow
26144830 CVE-2017-10352
26145911 Added detection for long running work requests and exclude them in thread count decision in enhanced increment advisor.
26248394 Fix for bug 26248394
26267487 ADFBC SERVER   DETECT QUIESCE MODE API
26268190 Fixed an issue where various management RMI calls are dispatched using default work manager instead of weblogic.admin.RMI work manager.
26353793 CVE-2019-2398
26439373 CVE-2017-5645
26473149 Fix NullPointerException that occurred if a WebApp is deployed from a Windows shared folder
26499391 Fixed failure to scale down BPM after it is registered with OTD
26502060 Fixed JTA determiners array processing to make it threadsafe
26547016 CVE-2018-2625
26589850 Fixed an issue wherein domainruntime.getserverruntime()would time out on a slow network
26608537 CVE-2018-2628
26624375 NODEMANAGER MEMORY LEAK ON SSL HANDSHAKE FAILURES
26626528 Fixed failure to start components simultaneously on the same host
26731253 Fix NoSuchMethodException that may occur for IdentityAsserter when DebugSecurityAtn is enabled
26806438 Fixed a NullPointerException condition that may occur when trying to activate an application
26828499 Fixed an issue where the host header was being incorrectly overritten when cluster frontend address is set
26835012 Fixed a deadlock condition with MBeanServerConnectionManager 
26929163 Fixed an issue with WLS schema owner permissions
26936500 Fixed an issue in the WebLogicDeploymentManager that caused the library deployments to not be returned
26985581 Fixed an issue where a java.lang.StringIndexOutOfBoundsException can occur 
27055227 Provided additional diagnostic information for IDCS integration
27111664 Fixed an issue with the WSDLReader
27117282 Fixed an issue where certgen was failing with jdk8 cpu (180161, b04, b05, b06)
27118731 Fix typo in debug message when DebugSecurityAtn is enabled
27131483 Fix method name in debug message when DebugSecurityAtn is enabled
27187631 Reduce IDCSIntegrator default value for connection timeout to 60s
27213775 NPE ON COM.ORACLE.INJECTION.INTEGRATION.MODULECONTAINERINTEGRATIONSERVICE
27234961 Improve performance of bean creation to reduce stuck threads when database is slow or down
27272911 Fixed an issue with javaURLContextFactory
27284496 Fixed extremely slow WebLogic start when there are large number of OSB projects
27411153 Fixed authentication for IDCS usernames with multi-byte characters
27417245 CVE-2018-2894
27445260 CVE-2018-2935
27469756 Fixed a memory leak in MBeanCICInterceptor that caused Admin Server to run out of memory.
27486993 Fixed a failure to undeploy applications from a dynamic cluster.
27516977 Fixed AccessControlException thrown while navigating Admin Console while Java Security Manager is enabled.
27561226 STRESS-OSB-STUCK THREADS DURING ALERT TESTING WHEN JMS QUEUE IS DOWN
27603087 Fixed an issue with an RCU cleanup script
27617877 Fixed failure in recovery of all configured determiners caused by concurrent access of NoTLOG resource state
27693510 Fixed default value for jax-rs-monitoring-default-behavior in WebApp container
27803728 CVE-2018-7489
27819370 CVE-2018-2987
27912485 WLS IDCS CLOUD INTEGRATOR TO SUPPORT 429 RESPONSE CODES FROM OPC (THROTTLING)
27927071 STRESS OIC ICS- NOSUCHELEMENTEXCEPTION DURING STRESS RUN
27928833 Fixed a server start issue where server boot will hang indefinitely when the JDBC TLOG feature is configured for the server and an empty string value is specified for the DomainMBean SiteName attribute.
27934864 CVE-2018-2998
27947832 Fixed an issue where javax.xml.XMLConstants.FEATURE_SECURE_PROCESSING wasn't being properly propagated in WSDLReader.
27948303 CVE-2018-2893
27988175 CVE-2018-3191
28071913 CVE-2018-3201
28103938 SECURITY ERROR CALLING EJB FROM WEBSTART APPLICATION USING THIN CLIENT
28110087 CVE-2019-2418
28138954 12.2.1.3.1 OHS  FAILED TO START OHS POST INSTALL DUE TO NEW REQ FOR MKTEMP PKG
28140800 Bypass version string checks when non-Oracle JDK is used.
28142116 TRACKING BUG FOR CIE BUG 27919131
28149607 CVE-2015-1832
28166483 TRACKING BUG TO CREATE WLS OVERLAY OF BUG 26001165 FIX FOR BLRS.
28171852 Fixed a ClassNotFoundException while deploying Gar that references a shared library.
28172380 Fix for 25800186 revised
28311332 Fix to remove duplicated call to PolicyFeatureUtils.getClientEffectivePolicySet(context)
28313163 HTTP SESSION OBJECTS DOESN'T ADHER SESSION TIMEOUT WHEN CLIENT TERMINATES REQUES
28319690 BASIC AUTH DOES NOT WORK WITH PASSWORDS CONTAINING BACKSLASH CHARACTER
28360225 Fixed NPE when JMS distributed destination does not have an active member during an internal search operation.
28375173 CVE-2018-3245
28375702 CVE-2018-3246
28409586 CVE-2018-3252
28503638 CTS J2EETOOLS TEST FAILED WITH FIX FOR BUG 26268190
28559579 CVE-2019-2441
28594324 PERF PROD HUGE TIME SPENT IN WEBLOGIC.SECURITY.ACL.INTERNAL.AUTHENTICATEDSUBJECT
28626991 CVE-2019-2452
28632521 CVE-2018-1000180

9 Known Issues
------------
For information about OPatch issues, see the following:

Doc ID 1587524.1 Using OUI NextGen OPatch 13 for Oracle Fusion Middleware 12c (12.1.2+)
https://support.oracle.com/rs?type=doc&id=1587524.1

For issues documented after the release of this WLS Patch Set Update, see the following:

Doc ID 2350415.1 Known Issues for Oracle WebLogic Server (OWLS) 12.2.1.3.X Patch Set Updates
https://support.oracle.com/rs?type=doc&id=2350415.1

If you are running with a security manager and experience
java.io.SerializablePermission "serialFilter" permission exceptions, then you
will need to update the weblogic policy file to include the following line:

    permission java.io.SerializablePermission "serialFilter";

in the coherence.jar section of the weblogic policy file:

   grant codeBase "file:@WL_HOME/../coherence/lib/coherence.jar" {

Note:  If your deployed application uses Java deserialization you may need to 
customize the WebLogic JEP 290 Default Filter.  For further information, 
refer to the "Restrict incoming serialized Java objects." line in the 
Securing Network Connections table at 
https://docs.oracle.com/middleware/12213/wls/LOCKD/secure.htm#GUID-9A5D9EE1-BE59-475C-BF61-19D4EFC6EDFF 

-----------------------------------------------------------------------------
DISCLAIMER:

This interim patch has only undergone basic unit testing, and has not been
through a complete test cycle generally followed for a production patch set.
Though the fixes in this document rectifies the bug, Oracle Corporation will
not be responsible for other issues that may arise due to these fixes.
Oracle Corporation recommends to later upgrade to the next production patch
set, when available. Applying this patch could overwrite other interim
patches applied since the last patch set. Customers need to make a request
to Oracle Support for a patch that includes those fixes, as well as inform
Oracle Support about all the patches installed when a Service Request is
opened. Please download, test, and provide feedback as soon as possible
to assist in the timely resolution of this problem.

Copyright (c)  2018, Oracle and/or its affiliates. All rights reserved.
----------------------------------------------------------------------------- 
